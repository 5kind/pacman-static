<h1 align="center">Systemless Pacman</h1>

<div align="center">
  <!-- Version -->
    <img src="https://github.com/chaitanyarahalkar/Pacman-Static"
      alt="Version" />
  <!-- Min Magisk -->
    <img src="https://img.shields.io/badge/MinMagisk-20.4-red.svg?longCache=true&style=flat-square"
      alt="_time_stamp_" />
  <!-- Min KSU -->
    <img src="https://img.shields.io/badge/MinKernelSU-0.6.6-red.svg?longCache=true&style=flat-square"
      alt="_time_stamp_" /></div>

<div align="center">
  <strong>Provide pacman-static in Android devices for pacstrap.

</div>

<div align="center">
  <h3>
    <a href="https://github.com/Zackptg5/MMT-Extended">
      Source Code
    </a>
  </h3>
</div>

### Usage
- Install chroot-service modules.
- pacstrap -h
