### v1.0 - 24.10.2023
* Initial release